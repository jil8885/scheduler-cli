from . import main
main.scheduler_server()
